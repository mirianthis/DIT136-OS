#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/wait.h>
#include <pthread.h>

int words = 0;

//Function to count words

void *WordCounter(void *var)
{
    FILE *file;
    file = fopen(var, "r");
    char a;

    while ((a = fgetc(file)) != EOF)
    {

        /* Check words */
        if (a == ' ' || a == '\n' || a == '\0' || a == '\t')

            words++;
    }

    fclose(file);
    pthread_exit(0);
}

int main(int argc, char **argv)
{

    struct dirent *pDirent;
    DIR *pDir;
    char *filenames[100];
    int i;
    char ch;

	//Check how many parameters the user gives
	if (argc != 2)
	{
		pDir = opendir(".");
	}
	if (argc == 2){
		pDir = opendir(argv[1]);
	}

    // Ensure we can open directory.   
    if (pDir == NULL)
    {
        printf("Cannot open directory '%s'\n", argv[1]);
        return 1;
    }

    // Process each entry.

    i = 0;
    while ((pDirent = readdir(pDir)) != NULL)
    {
        //Save the names of the files of the dir in an array
        filenames[i] = (pDirent->d_name);
        FILE *file;
        int pid, status;
        char path[1000];
        char c1[2] = "/";

        //Create the path to open the file
        strcpy(path, argv[1]);
        strcat(path, c1);
        strcat(path, filenames[i]);

        //Open file
        file = fopen(path, "r");

        char c;
        int bytes;
        //Read file char by char
        int counter = 0;
        while ((c = fgetc(file)) != EOF)
        {
            //Check if it is ascii
            if (c < 0 || c > 127)
            {
                counter = 1;
                break;
            }
        }

        if (counter == 1)
        {
            //printf("File is not ascii and the path is %s\n",path);
        }

        else
        {
            //printf("File is ascii and the path is %s\n",path);

            //Call fork
            if ((pid = fork()) == -1) /*check for error*/
            {
                perror("fork");
                exit(1);
            }

            if (pid == 0) /*The child process*/
            {         	
		        //Create thread and use WordCounter function to find the words
                pthread_t tid;
                pthread_create(&tid, NULL, WordCounter, path);

                pthread_join(tid, NULL);

                FILE *fd;
                fd = fopen("output.txt", "a+");
                if (fd == NULL)
                {
                    printf("Error opening file\n");
                    exit(1);
                }
				//Check if file is empty
                if (words == 0)
                {
                    return 0;
                }
				//Print to the file
                else
                {
                    if (i == 0)
                    {
                        fprintf(fd, "PID      FILENAME    WORDS\n");
                    }
                    fprintf(fd, "%d    %s       %d\n", getpid(), pDirent->d_name, words);
                }
				fclose(fd);				
                exit(0);
            }
            wait(NULL);
            i++;
        }
    }

    // Close directory and exit.
    closedir(pDir);
}
